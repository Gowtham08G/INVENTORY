/**
 * 
 */
/**
 * 
 */
module inventoryApplication {
	requires java.sql;
}