package connectionManager;

public class Login {
	private int ID;
	private String USERNAME;
	private String PASSWORD;
	private long MOBILE_NUMBER;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}
	public String getPASSWORD() {
		return PASSWORD;
	}
	public void setPASSWORD(String pASSWORD) {
		PASSWORD = pASSWORD;
	}
	public long getMOBILE_NUMBER() {
		return MOBILE_NUMBER;
	}
	public void setMOBILE_NUMBER(long mOBILE_NUMBER) {
		MOBILE_NUMBER = mOBILE_NUMBER;
	}

	
}
